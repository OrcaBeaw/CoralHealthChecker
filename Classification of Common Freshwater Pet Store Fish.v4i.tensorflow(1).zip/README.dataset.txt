# Classification of Common Freshwater Pet Store Fish > 2023-04-27 7:58pm
https://universe.roboflow.com/for-the-fish/classification-of-common-freshwater-pet-store-fish-3dvvi

Provided by a Roboflow user
License: CC BY 4.0

